const router = require('express').Router();

const students = [
    {
        name: "AUSTIN M ADEGAH",
        DOB: "27/04/1990",
        program: "BSC INFORMATION & COMMUNICATION TECHNOLOGY",
        level: "200",
        image:"/images/img1.jpg"
    },
    {
        name: "CLARA ADOKPA",
        DOB: "12/20/1996",
        program: "BSC BUSINESS ADMINISTRATION",
        level: "200",
        image:"/images/img2.jpg"
    },
    {
        name: "EVELYN GYAMFI",
        DOB: "23/20/1986",
        program: "BSC MARKETING",
        level: "200",
        image:"/images/img3.jpg"
    },
    {
        name: "CYRIL J ADOKPAH",
        DOB: "09/10/1997",
        program: "BSC PUBLIC ADMINISTRATION",
        level: "200",
        image:"/images/img4.jpg"
    },
    {
        name: "JASON ADEGAH",
        DOB: "12/06/1988",
        program: "BSC COMPUTER SCIENCE",
        level: "200",
        image:"/images/img5.jpg"
    }
]


router.get('/', (req, res)=>{
    res.render('home', {
        title:'Home',
        students
    })
});

router.get('/student/:id', (req, res)=>{
    const id = req.params.id;
    const student = students[id];
    res.render('student', {
        title: students[id].name,
        student
    })
});

module.exports = router;